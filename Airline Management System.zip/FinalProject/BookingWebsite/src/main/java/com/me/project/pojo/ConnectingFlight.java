package com.me.project.pojo;

import java.util.Date;

public class ConnectingFlight {

	private String first_flight_no;
	
	private String second_flight_no;
	
	private String source;
	
	private String connection;
	
	private String destination;
	
	
	private Date departure_date;
	
	private Date connection_date;
	
	private Date arrival_date;

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getConnection() {
		return connection;
	}

	public void setConnection(String connection) {
		this.connection = connection;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Date getDeparture_date() {
		return departure_date;
	}

	public void setDeparture_date(Date departure_date) {
		this.departure_date = departure_date;
	}

	public Date getConnection_date() {
		return connection_date;
	}

	public void setConnection_date(Date connection_date) {
		this.connection_date = connection_date;
	}

	public Date getArrival_date() {
		return arrival_date;
	}

	public void setArrival_date(Date arrival_date) {
		this.arrival_date = arrival_date;
	}

	public String getFirst_flight_no() {
		return first_flight_no;
	}

	public void setFirst_flight_no(String first_flight_no) {
		this.first_flight_no = first_flight_no;
	}

	public String getSecond_flight_no() {
		return second_flight_no;
	}

	public void setSecond_flight_no(String second_flight_no) {
		this.second_flight_no = second_flight_no;
	}
	
	
	
}
