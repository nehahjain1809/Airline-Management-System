package com.me.project;

import java.util.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.helpers.DateTimeDateFormat;
import org.hibernate.HibernateException;
import org.hibernate.query.Query;
import org.hibernate.Session;
import org.relique.jdbc.csv.CsvConnection;
import org.relique.jdbc.csv.CsvPreparedStatement;
import org.relique.jdbc.csv.CsvResultSet;

import com.me.project.dao.DAO;
import com.me.project.pojo.Airline;
import com.me.project.pojo.Flight;



public class UploadHelper extends DAO{

	public List<Flight> parseData(String filename) throws ClassNotFoundException, SQLException {
		
		
		try{
		Class.forName("org.relique.jdbc.csv.CsvDriver");
        CsvConnection conn=(CsvConnection) DriverManager.getConnection("jdbc:relique:csv:");
        CsvPreparedStatement stmt = (CsvPreparedStatement) conn.prepareStatement("select * FROM "+filename+ ";");
        CsvResultSet results =(CsvResultSet) stmt.executeQuery("select * FROM "+filename + ";");
        
        List<Flight> flights = new ArrayList<Flight>();
        
        System.out.println("connection: " +conn);
        System.out.println("statement: " +stmt);
        
        while(results.next()){
        	Flight flight = new Flight();
        	System.out.println("results");
        	try {
        	Session session = DAO.getSession();
        	Query query = session.getNamedQuery("findAirlineById").setInteger("airline_id", results.getInt("airline_id"));
        	query.setMaxResults(1);
        	Airline airline = (Airline) query.uniqueResult();
        	
        	String flight_no=results.getString("flight_no");
        	String departure_city=results.getString("departure_city");
        	String arrival_city=results.getString("arrival_city");
        	System.out.println("results1");
        	
        	String departure_date_string=results.getString("departure_date");
        	String arrival_Date_string=results.getString("arrival_Date");
        	System.out.println("departure_date_string"+ departure_date_string);
        	System.out.println("arrival_Date_string"+ arrival_Date_string);
        	
        	Date departure_date=(Date) new SimpleDateFormat("MM/dd/yyyy HH:mm").parse(departure_date_string);
        	Date arrival_Date=(Date) new SimpleDateFormat("MM/dd/yyyy HH:mm").parse(arrival_Date_string);
        	System.out.println("departure_date"+ departure_date);
        	
        	System.out.println("arrival_Date"+ arrival_Date);
        	int totalEconomySeats=results.getInt("totalEconomySeats");
        	int totalFirstSeats=results.getInt("totalFirstSeats");
        	int totalBusinessSeats=results.getInt("totalBusinessSeats");
        	
        	System.out.println(totalBusinessSeats);
        	
        	Flight f = new Flight();
        	f.setFlight_no(flight_no);
        	f.setAirline(airline);
        	f.setDeparture_city(departure_city);
        	f.setArrival_city(arrival_city);
        	f.setDeparture_date(departure_date);
        	f.setArrival_Date(arrival_Date);
        	f.setTotalBusinessSeats(totalBusinessSeats);
        	f.setTotalEconomySeats(totalEconomySeats);
        	f.setTotalFirstSeats(totalFirstSeats);
        	//f.initializeSeats(totalBusinessSeats,totalEconomySeats,totalFirstSeats);
        	flights.add(f);
        	
        	}
        	catch(HibernateException e) {
        		e.printStackTrace();
        	}
        }
        System.out.println("flights: " + flights);
        return flights;
		}
    	catch(Exception e) {
    		e.printStackTrace();
    		return null;
    	}
		
	}
}
