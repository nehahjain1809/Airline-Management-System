package com.me.project.pojo;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="booking")
@NamedQueries ({

	@NamedQuery(name = "findBookingByID", query = "FROM Booking where booking_id = :booking_id")
	
	})
public class Booking {

	
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int booking_id;
	
	@ManyToOne()
    @JoinColumn(name="user_id")
    private User user;
	
	@ManyToOne()
    @JoinColumn(name="flight_id")
	private Flight flight;
	
	@OneToOne()
    @JoinColumn(name="id")
	private Seat seat;
	
	@Column(name="booking_date")
	private Date booking_date;
	
	@Column(name="booking_cost")
	private float booking_cost;

	public int getBooking_id() {
		return booking_id;
	}

	public void setBooking_id(int booking_id) {
		this.booking_id = booking_id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Flight getFlight() {
		return flight;
	}

	public void setFlight(Flight flight) {
		this.flight = flight;
	}

	public Seat getSeat() {
		return seat;
	}

	public void setSeat(Seat seat) {
		this.seat = seat;
	}

	public Date getBooking_date() {
		return booking_date;
	}

	public void setBooking_date(Date booking_date) {
		this.booking_date = booking_date;
	}

	public float getBooking_cost() {
		return booking_cost;
	}

	public void setBooking_cost(float booking_cost) {
		this.booking_cost = booking_cost;
	}
	
	
	
}
