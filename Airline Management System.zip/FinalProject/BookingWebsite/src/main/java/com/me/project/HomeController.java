package com.me.project;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.captcha.botdetect.web.servlet.Captcha;
import com.me.project.dao.CityDAO;
import com.me.project.dao.UserDAO;
import com.me.project.pojo.User;



/**
 * Handles requests for the application home page.
 */
@Controller
@RequestMapping(value="/user/*")
public class HomeController {
	
	
//	@Autowired
//	@Qualifier("userDao")
//	UserDAO userDao;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		return "home";
	}
	
	@RequestMapping(value = "/user/signup", method = RequestMethod.GET)
	public String showCreateForm(ModelMap model) {
		User user = new User();
		model.addAttribute("user", user);
		return "signup-form";
	}
	
	@RequestMapping(value="/user/register", method = RequestMethod.POST)
	public String handleCreateForm(HttpServletRequest request, UserDAO userDao, ModelMap map) {
	    
	    // captcha object
	    Captcha captcha = Captcha.load(request, "CaptchaObject");
	    
	    // captcha code the user typed id
	    String captchaCode = request.getParameter("captchaCode");
	    
	    //creating a session
	    HttpSession session=request.getSession();
	    
	    if(captcha.validate(captchaCode)){
	        User user = new User();
	       
	        user.setFullname(request.getParameter("name"));
	        user.setContact(request.getParameter("contact"));
	        user.setPassport(request.getParameter("passport"));
	        user.setEmailId(request.getParameter("emailId"));
	        user.setRole("customer");
	        String userEmail= request.getParameter("username");
	        String password = request.getParameter("pwd");
	        user.setUsername(userEmail);
	        user.setPwd(password);
	        
	        try{
	        User u = userDao.register(user);
	        return "signup-success";
	        
	        }catch(Exception e){
	            e.printStackTrace();
	        }
//	        
	    }else
	    {
	        map.addAttribute("errorMessage","Invalid Captcha Code");
	        return "error-page";
	    }
		return "error-page";
	 
	}

	
	@RequestMapping(value = "/user/login", method = RequestMethod.POST) 
	public String handleLoginForm(HttpServletRequest request, HttpServletResponse response, 
			UserDAO userDao, ModelMap map) {

		String username = request.getParameter("username");
		String password = request.getParameter("pwd");
		System.out.println(username);
		System.out.println(password);
		HttpSession session = request.getSession();
		session.setAttribute("username", username);
		
		boolean remember;
		
		 if(request.getParameter("rememberme") == null){
	         remember = false;  
	       
	       }
	       else{
	           remember = true;
	           
	       }
		try {
			User u = userDao.get(username, password);
			System.out.println(u);
			if (u != null) {
				if(remember) { 
					System.out.println(remember);
				Cookie ck=new Cookie("username",username); 
	            ck.setMaxAge(60*60);
	            response.addCookie(ck);  
				}
				
				if(u.getRole().equals("customer")){
	            return "user-dashboard";
				}
				else {
					return "admin-dashboard";
				}
				
			} 
			else {
				
				map.addAttribute("errorMessage", "Invalid username/password!");
				return "error-page";
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "error-page";
		}

		

	}
	
	@RequestMapping(value = "/user/ajaxservice", method = RequestMethod.POST)
	@ResponseBody
	public String ajaxService(HttpServletRequest request, CityDAO cityDao)
	{

		List<String> allCityList = cityDao.getAllCities();
		String queryString = request.getParameter("city");
		System.out.println("Querystring:"+ queryString);
		String result = "";
		if( queryString.length() > 0) {
			System.out.println("in Querystring:");
		for(int i = 0; i< allCityList.size(); i++){
			if(allCityList.get(i).toLowerCase().contains(queryString.toLowerCase())){
				result += allCityList.get(i)+",";
			}
		}
		
		}
		else { return null; }

		return result;
	}
	
	/*@RequestMapping(value = "/user/ajaxservice1", method = RequestMethod.POST)
	@ResponseBody
	public String ajaxService1(HttpServletRequest request, FlightDAO flightDao)
	{

		int seatno = Integer.parseInt(request.getParameter("seatno"));
		int flight_id = Integer.parseInt(request.getParameter("flightid"));
		String seattype = request.getParameter("seatno");
		
		float price = flightDao.getPriceBySeatType(seattype, flight_id);
		
		return String.valueOf(price);
		
	}*/
	
}
