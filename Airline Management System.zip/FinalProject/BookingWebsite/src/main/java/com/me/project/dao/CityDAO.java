package com.me.project.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Transaction;


import com.me.project.pojo.City;
import com.me.project.pojo.Flight;
import com.me.project.pojo.User;

public class CityDAO extends DAO {

	public CityDAO() {
		
	}
	
	public void add(City city){
		try {
			Transaction tx = getSession().getTransaction();
			tx.begin();
			
				getSession().save(city);
			
			tx.commit();
			}
			catch(HibernateException e) {
				e.printStackTrace();
			}
		
	}
	
public List<String> getAllCities() {
		
		List<String> allCityList = getSession().getNamedQuery("findAllCities").list();
		System.out.println("allCityList :" + allCityList.size());
		return allCityList;
	}
	

}
