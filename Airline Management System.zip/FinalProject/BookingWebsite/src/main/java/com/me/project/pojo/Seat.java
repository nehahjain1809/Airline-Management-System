package com.me.project.pojo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="seat")

@NamedQueries ({
	@NamedQuery(name = "findSeattById", query = "FROM Seat where seat_id = :seat_id"),
	@NamedQuery(name = "findSeattByType", query = "FROM Seat where seattype = :seattype"),
	@NamedQuery(name = "findSeatBypID", query = "FROM Seat where id = :id")
	
	})
public class Seat {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="id")
	private int id;
	
	@Column(name="seat_id")
	private String seat_id;
	
	@Column(name="seatType")
	private String seatType;
	
	@Column(name="seatPrice")
	private float seatPrice;
	
	@Column(name="seatstatus")
	private boolean isBooked;
	
	@Column(name="allowed_baggage")
	private int allowed_baggage;
	
	@Column(name="checkinstatus")
	private boolean isCheckedIn;
	
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="flightid" , referencedColumnName="flight_id")
	private Flight flight;
	
	@OneToOne()
    @JoinColumn(name="booking_id")
	private Booking booking;


	public Seat() {
		
	}




	public String getSeat_id() {
		return seat_id;
	}




	public void setSeat_id(String seat_id) {
		this.seat_id = seat_id;
	}





	public String getSeatType() {
		return seatType;
	}




	public void setSeatType(String seatType) {
		this.seatType = seatType;
	}




	public float getSeatPrice() {
		return seatPrice;
	}


	public void setSeatPrice(float seatPrice) {
		this.seatPrice = seatPrice;
	}


	public Flight getFlight() {
		return flight;
	}


	public void setFlight(Flight flight) {
		this.flight = flight;
	}


	public boolean isBooked() {
		return isBooked;
	}


	public void setBooked(boolean isBooked) {
		this.isBooked = isBooked;
	}


	public int getAllowed_baggage() {
		return allowed_baggage;
	}


	public void setAllowed_baggage(int allowed_baggage) {
		this.allowed_baggage = allowed_baggage;
	}


	public boolean isCheckedIn() {
		return isCheckedIn;
	}


	public void setCheckedIn(boolean isCheckedIn) {
		this.isCheckedIn = isCheckedIn;
	}


	public Booking getBooking() {
		return booking;
	}


	public void setBooking(Booking booking) {
		this.booking = booking;
	}




	public int getId() {
		return id;
	}




	public void setId(int id) {
		this.id = id;
	}
	
	
	
}
