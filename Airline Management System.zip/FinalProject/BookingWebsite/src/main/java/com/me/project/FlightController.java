package com.me.project;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.mail.internet.MimeMessage;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;

import com.me.project.dao.FlightDAO;
import com.me.project.dao.SeatDAO;
import com.me.project.dao.UserDAO;
import com.me.project.pojo.Booking;
import com.me.project.pojo.ConnectingFlight;
import com.me.project.pojo.Flight;
import com.me.project.pojo.Seat;
import com.me.project.pojo.User;

@Controller
@RequestMapping(value="/flight/*")
public class FlightController {
	
//	@Autowired
//	   private JavaMailSender mailSender;
	@Autowired
	ServletContext context;
	
	@RequestMapping(value="/flight/search", method = RequestMethod.POST)
	public String searchFlights(HttpServletRequest request, FlightDAO flightDao, ModelMap map) throws Exception {
		String tripOption = request.getParameter("tripop");
		System.out.println("option:"+ tripOption);
		try{
		if(tripOption.equals("oneway")) {
			System.out.println("option:"+ tripOption);
			List<Flight> searchedFlights =  new ArrayList<Flight>();
			
			
			String departure_airport =  request.getParameter("from_airport");
			String arrival_airport =  request.getParameter("to_airport");
			
						
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date departure_date = format.parse(request.getParameter("from"));
			if(departure_date.before(new Date())) {
				request.setAttribute("msg", "invalid dates selected. please retry");
				return "user-dashboard";
			}
			else{
			searchedFlights = flightDao.search(departure_airport, arrival_airport, departure_date);
			request.setAttribute("searchedFlights", searchedFlights);
			return "flight-search-success";
			}
			}

		else if(tripOption.equals("twoway")) {
			System.out.println("option:"+ tripOption);
			List<Flight> fromFlights =  new ArrayList<Flight>();
			List<Flight> returnFlights =  new ArrayList<Flight>();
			
			System.out.println("option:"+ tripOption);
			System.out.println("option:"+ tripOption);
			
			String departure_airport =  request.getParameter("from_airport2");
			String arrival_airport =  request.getParameter("to_airport2");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date departure_date = format.parse(request.getParameter("from2"));
			Date arrival_date = format.parse(request.getParameter("to2"));
			System.out.println("departure_date:"+ departure_date);
			System.out.println("arrival_date:"+ arrival_date);
			
			
			if(departure_date.before(arrival_date) || !departure_date.before(new Date())) {
			System.out.println("Yes" + "departure_date:"+ departure_date +"arrival_date:"+ arrival_date);
			
			System.out.println("from:"+ departure_airport);
			System.out.println("to:"+ arrival_airport);
			System.out.println("on:"+ departure_date);
			
			fromFlights = flightDao.search(departure_airport, arrival_airport, departure_date);
			System.out.println("fromFlights:"+ fromFlights.size());
			
			System.out.println("from:"+ arrival_airport);
			System.out.println("to:"+ departure_airport);
			System.out.println("on:"+ arrival_date);
			try{
			returnFlights = flightDao.search(arrival_airport, departure_airport, arrival_date);
			System.out.println("returnFlights:"+ returnFlights.size());
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			request.setAttribute("fromFlights", fromFlights);
			request.setAttribute("returnFlights", returnFlights);
			
			return "flight-search-success";
			}
			else {
				request.setAttribute("msg", "invalid dates selected. please retry");
				return "user-dashboard";
			}
		}
		
		else {
			System.out.println("option:"+ tripOption);
			
			String departure_airport =  request.getParameter("from_airport1");
			String arrival_airport =  request.getParameter("to_airport1");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date departure_date = format.parse(request.getParameter("from1"));
			Date arrival_date = format.parse(request.getParameter("to1"));
			
			System.out.println("departure_date:"+ departure_date);
			System.out.println("arrival_date:"+ arrival_date);
			
			List<Flight> fromSourceFlights =  new ArrayList<Flight>();
			List<Flight> toDestinationFlights =  new ArrayList<Flight>();
			List<ConnectingFlight> connectingFlights_all =  new ArrayList<ConnectingFlight>();
			try{
			if(1==1){
				
				
					fromSourceFlights	= flightDao.searchAllFlightsFrom(departure_airport, departure_date);
					for(Flight f : fromSourceFlights){
						
						Date arrival_date21 = f.getArrival_Date();
						Calendar c = Calendar.getInstance();
				        c.setTime(arrival_date21);
				        c.add(Calendar.MINUTE, 30);
				        Date departure_date_next = c.getTime();
				        
				        List<Flight> connectingFlights =  new ArrayList<Flight>();
				        
						connectingFlights = flightDao.search(f.getArrival_city(), arrival_airport ,departure_date_next);
						
							if(connectingFlights.size() >0) {
								
								for(Flight f_next: connectingFlights) {
									System.out.println("dearture time of connection: "+ f_next.getDeparture_date());
									if(f_next.getDeparture_date().after(f.getArrival_Date())){
									toDestinationFlights.add(f_next);
									
									ConnectingFlight cf = new ConnectingFlight();
									cf.setSource(f.getDeparture_city());
									cf.setConnection(f.getArrival_city());
									cf.setDestination(f_next.getArrival_city());
									cf.setDeparture_date(f.getDeparture_date());
									cf.setConnection_date(f_next.getDeparture_date());
									cf.setArrival_date(f_next.getArrival_Date());
									cf.setFirst_flight_no(f.getFlight_no());
									cf.setSecond_flight_no(f_next.getFlight_no());
									connectingFlights_all.add(cf);
								}
								}
							}	
					}
					request.setAttribute("connectingFlights_all", connectingFlights_all);
					
					System.out.println("all flights from source");
					for(Flight f: fromSourceFlights) {
						System.out.println("source : " + f.getDeparture_city() + " connection " + f.getArrival_city());
					}
					System.out.println("all flights to destination");
					
					for(Flight f: toDestinationFlights) {
						System.out.println("source : " + f.getDeparture_city() + " connection " + f.getArrival_city());
					}
					
					System.out.println("all flights received");
					for(ConnectingFlight f: connectingFlights_all) {
						System.out.println("source : " + f.getSource() + " connection " + f.getConnection() + " destination " +f.getDestination());
					}
					
					return "flight-search-success";
				}
			
			}
			catch(Exception e) {
			e.printStackTrace();
			}
		
		}
		}
		catch(Exception e) {
			e.printStackTrace();
			return "error-page";
		}
		return null;
		
	}
	
	
	@RequestMapping(value="/flight/upload" , method = RequestMethod.POST)
	public String uploadFlightData(HttpServletRequest request, HttpServletResponse response , ModelMap model) throws ClassNotFoundException, SQLException{
		HttpSession session = request.getSession();
		String filename	= request.getParameter("filename");
		System.out.println(filename);
        if(!filename.equals("")){
        	UploadHelper uploadHelper = new UploadHelper();
        	List<Flight> flights = uploadHelper.parseData(filename);
        	request.setAttribute("flights", flights);
        	session.setAttribute("flightsToAdd", flights);
        	System.out.println(flights.size());
        	return "admin-dashboard";
        }
        else {
        	session.setAttribute("message", "Invalid Filename");
        	return  "Invalid Filename";
        }
		
		
	}
	
	@RequestMapping(value="/flight/add" , method = RequestMethod.POST)
	public String addFlightData(HttpServletRequest request, FlightDAO flightDao, HttpServletResponse response , ModelMap model) {
		HttpSession session = request.getSession();
		try {
        List<Flight> flightsToAdd = (List<Flight>) session.getAttribute("flightsToAdd");
        flightDao.addFlights(flightsToAdd);
        return "admin-dashboard";
		}
		catch(Exception e) {
			e.printStackTrace();
			return "error-page";
		}
		
		
	}
	
	@RequestMapping(value="/flight/view", method = RequestMethod.POST)
	public String viewFlights(HttpServletRequest request, FlightDAO flightDao, ModelMap map) throws Exception {
		HttpSession session = request.getSession();
		try {
		List<Flight> allFlights = flightDao.viewAll();
		request.setAttribute("allFlights", allFlights);
    	System.out.println("in view:"+allFlights);
    	return "admin-dashboard";
	}
	catch(Exception e) {
		e.printStackTrace();
		return "error-page";
	}
		
		
	}
	
	@RequestMapping(value="/flight/delete", method = RequestMethod.POST)
	public String deleteFlightData(HttpServletRequest request, HttpServletResponse response , FlightDAO flightDao, ModelMap model){
		System.out.print("delete");
		try{
		String[] flighsToDelete =  request.getParameterValues("deleteSelect");
		for (String str : flighsToDelete) {
			int flight_id = Integer.parseInt(str);
			System.out.print(flight_id);
			
        	flightDao.delete(flight_id);
		}
		 
		 return "admin-dashboard";
		}
		catch(Exception e) {
			e.printStackTrace();
			return "error-page";
		}
	}
	
	@RequestMapping(value="/flight/buy" , method = RequestMethod.POST)
	public String buyFlighREquest(HttpServletRequest request, FlightDAO flightDao, HttpServletResponse response , ModelMap model) {
		HttpSession session = request.getSession();
		try {
        
		int flight_id_to_buy = Integer.parseInt(request.getParameter("buySelect"));
		Flight flight_to_buy = flightDao.get(flight_id_to_buy);
		request.setAttribute("flight_to_buy", flight_to_buy);
		System.out.print(flight_id_to_buy);
        return "make-reservation";
		}
		catch(Exception e) {
			e.printStackTrace();
			return "error-page";
		}
		
		
	}
	
	@RequestMapping(value="/flight/pay" , method = RequestMethod.POST)
	public String payFlightBooking(HttpServletRequest request, FlightDAO flightDao, HttpServletResponse response , ModelMap model) {
		HttpSession session = request.getSession();
		try {
        
		Booking b = (Booking) session.getAttribute("booking");	
		Seat s = (Seat)session.getAttribute("seat");
		System.out.print(b.getBooking_id());
		System.out.print(s.getSeat_id());
		
		int bookingid= flightDao.saveBooking(b, s);		
		
		UserDAO userDao = new UserDAO();
		User u = userDao.get((String)session.getAttribute("username"));
		
		String  emailaddress =  u.getEmailId();
		System.out.println("hi usernamenemail: "+ emailaddress);
		String messagebody = "Your ticket has been booked successfully. Booking Reference: "+ b.getBooking_id() +
				" . Seat No: " + s.getSeat_id() + 
				". You are allowed  "+ s.getAllowed_baggage()+
				"  of 23 kg each and a cabin bag of 7 kg. Please contact on your"
						+ " tollfree number for any queries";
		//sendEmail(emailaddress, messagebody);
		
		
        return "book-success";
		}
		catch(Exception e) {
			e.printStackTrace();
			return "error-page";
		}
		
		
	}
	
	@RequestMapping(value="/flight/addseats" , method = RequestMethod.POST)
	public String addFlightSeatData(HttpServletRequest request, FlightDAO flightDao, HttpServletResponse response , ModelMap model) {
		HttpSession session = request.getSession();
		try {
        
		String flight_no = request.getParameter("flightno");
		System.out.println("System.out.print(flight_no);"+flight_no);
		
        flightDao.addSeats(flight_no, 60, 60, 60);
        
        return "admin-dashboard";
		}
		catch(Exception e) {
			e.printStackTrace();
			return "error-page";
		}
		
		
	}
	
	@RequestMapping(value = "/flight/ajaxservice1", method = RequestMethod.POST)
	@ResponseBody
	public String ajaxService1(HttpServletRequest request, FlightDAO flightDao)
	{
		System.out.println("hi 1");
		String seatno = request.getParameter("seatno");
		int flight_id = Integer.parseInt(request.getParameter("flightid"));
		String seattype = request.getParameter("seattype");
		
		System.out.println("hi seatno"+seatno);
		System.out.println("hi flight"+ flight_id);
		System.out.println("hi seat"+seattype);
		
		float price = flightDao.getPriceBySeatType(seattype, flight_id);
		System.out.println("hi price"+price);
		return String.valueOf(price);
		
	}
	
	@RequestMapping(value="/flight/proceed" , method = RequestMethod.POST)
	public String proceedToPay(HttpServletRequest request, FlightDAO flightDao, HttpServletResponse response , ModelMap model) {
		HttpSession session = request.getSession();
		try {
       
		String cost = request.getParameter("price");
		String flight_id = request.getParameter("flightid");
		String seat_id = request.getParameter("seatnumber");
		String username= (String) session.getAttribute("username");
		String seat_type= request.getParameter("name2");
		
		System.out.println("hi seatno "+seat_id);
		System.out.println("hi flight "+ flight_id);
		System.out.println("hi cost "+ cost);
		System.out.println("hi username"+username);
		System.out.println("hi seat_type"+seat_type);
		
		UserDAO userDao = new UserDAO();
		User u = userDao.get(username);
		System.out.println("hi usernamenew: "+ u.getPwd());
		
		Flight flight = flightDao.get(Integer.parseInt(flight_id));
		System.out.println("hi flight: "+ flight.getFlight_id());
		int flid = flight.getFlight_id();
		Seat seat = null;
		
		List<Seat> seatsList = flight.getSeats();
		System.out.println("seat: "+ seatsList.size());
		for(Seat s: seatsList) {
			String s_t =  s.getSeatType().toString().toLowerCase();
			if(s.getSeat_id().equals(seat_id)){
				System.out.println("seat: "+ s.getSeat_id() + "type " + s.getSeatType());
				seat = s;		
			}
		}
		SeatDAO seatDao = new SeatDAO();
		
//		Seat seat= seatDao.get(seat_id, flight, seat_type);
		//System.out.println("hi seat: "+ seat.getSeat_id());
		
		int user_id =u.getUserId();
		System.out.println(username);
		
		Booking b = new Booking();
		b.setUser(u);
		b.setFlight(flight);
		b.setBooking_cost(Float.parseFloat(cost));
		b.setSeat(seat);
		b.setBooking_date(new Date());
		
		if(seat.isBooked()){
			String msg = "seat is already booked. Please select another one.";
			request.setAttribute("msg", msg);
			return "make-reservation";
		} else{
		seat.setBooked(true);
		seat.setBooking(b);
		}
		session.setAttribute("booking", b);
		session.setAttribute("seat", seat);
		
		
		
        return "payment";
		}
		catch(Exception e) {
			e.printStackTrace();
			return "error-page";
		}
		
		
	}
	
//	public void sendEmail(String useremail, String message) {
//		try {
//			Email email = new SimpleEmail();
//			email.setHostName("smtp.googlemail.com");
//			email.setSmtpPort(587);
//			email.setAuthenticator(new DefaultAuthenticator("contactapplication2018@gmail.com", "springmvc"));
//			email.setSSLOnConnect(true);
//			email.setFrom("no-reply@msis.neu.edu"); // This user email does not
//													// exist
//			email.setSubject("Booking Confirmation");
//			email.setMsg(message); // Retrieve email from the DAO and send this
//			email.addTo(useremail);
//			
//			email.send();
//		} catch (EmailException e) {
//			e.printStackTrace();
//			System.out.println("Email cannot be sent");
//		}
//	}
	
//	@RequestMapping(value = "/flight/pay1", method = RequestMethod.GET)
//    public String send(HttpServletRequest request) {
//    return "make-email";    
//       
//   }
//
//   @RequestMapping(value = "/flight/pay1",method = RequestMethod.POST)
//   public String sendEmail(HttpServletRequest request) {
//
//       // reads form input
//       final String emailTo = request.getParameter("mailTo");
//       final String subject = request.getParameter("subject");
//       final String message = request.getParameter("message");
//
//       // for logging
//       System.out.println("emailTo: " + emailTo);
//       System.out.println("subject: " + subject);
//       System.out.println("message: " + message);
//      
//
//       mailSender.send(new MimeMessagePreparator() {
//
//           @Override
//           public void prepare(MimeMessage mimeMessage) throws Exception {
//               MimeMessageHelper messageHelper = new MimeMessageHelper(
//                       mimeMessage, true, "UTF-8");
//               messageHelper.setTo(emailTo);
//               messageHelper.setSubject(subject);
//               messageHelper.setText(message);
//               
//               
//               
//           }
//
//       });
//
//       return "Result-page";
//   }
	
	@RequestMapping(value="/flight/downloads/{fileName:.+}")
	public void downloader(HttpServletRequest request, HttpServletResponse response,@PathVariable("fileName") String fileName) {
	 
	 System.out.println("Downloading file :- " + fileName);

	 String downloadFolder = context.getRealPath("/WEB-INF/downloads/");
	 Path file = Paths.get(downloadFolder, fileName);
	 // Check if file exists
	 if (Files.exists(file)) {
	  // set content type
	  response.setContentType("application/pdf");
	  // add response header
	  response.addHeader("Content-Disposition", "attachment; filename=" + fileName);
	  try {
	   //copies all bytes from a file to an output stream
	   Files.copy(file, response.getOutputStream());
	   //flushes output stream
	   response.getOutputStream().flush();
	  } catch (IOException e) {
	   System.out.println("Error :- " + e.getMessage());
	  }
	 } else {
	  System.out.println("Sorry File not found!!!!");
	 }
	}
	
	@RequestMapping(value="/flight/managebooking" , method = RequestMethod.POST)
	public String managemybooking(HttpServletRequest request, FlightDAO flightDao, UserDAO userDao,
			HttpServletResponse response , ModelMap model) {
		HttpSession session = request.getSession();
		try {
			
			String username= (String) session.getAttribute("username");
			String name =request.getParameter("name");
			String ref=request.getParameter("booking_reference");
			int reference = Integer.parseInt(ref);
			System.out.println("booking id :- " + reference);
			
			User u = userDao.get(username);
			
			Booking b = userDao.getBooking(reference);
			if(b.getUser().getFullname().equals(name)){
			System.out.println("booking id :- " + b.getBooking_id());
			request.setAttribute("mybooking", b);
			request.setAttribute("myseat", b.getSeat());
			request.setAttribute("myflight", b.getFlight());
        return "booking-dashboard";
			}
			else{
				return "user-dashboard";
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			return "error-page";
		}
		
		
	}
	
	@RequestMapping(value="/flight/checkin" , method = RequestMethod.POST)
	public String checkin(HttpServletRequest request, FlightDAO flightDao, UserDAO userDao, SeatDAO seatDao,
			HttpServletResponse response , ModelMap model) {
		HttpSession session = request.getSession();
		System.out.println("here");
		try {
			
			String s_id =  request.getParameter("seatid");
			String s_no =  request.getParameter("seatno");
			System.out.println(s_id+ " " + s_no);
			int seat_id = Integer.parseInt(s_id);
			System.out.println("seat id1 :- " + seat_id);
			
			Seat s = seatDao.getSeatById(seat_id);
			System.out.println("in loo bookstatus :- " + s.isBooked());
			
			if(s.isBooked()) {
				System.out.println("in loo seat id :- " + s.getSeat_id());
				s.setCheckedIn(true);
				seatDao.save(s);
				return "checkin-success";
				}
			else {
				return "error-page";
			}
//			System.out.println("seat id :- " + s.getSeat_id());
        
		}
		catch(Exception e) {
			e.printStackTrace();
			return "error-page";
		}
		
		
	}
	
	
}
