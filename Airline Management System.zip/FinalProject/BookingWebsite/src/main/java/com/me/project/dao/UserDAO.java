package com.me.project.dao;


import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;

import com.me.project.pojo.Booking;
import com.me.project.pojo.User;


public class UserDAO extends DAO {

	public UserDAO() {
	}

	public User get(String username, String pwd) throws Exception {
		try {
			begin();
			Query q = getSession().createQuery("from User where username = :username and pwd = :pwd");
			q.setString("username", username);
			q.setString("pwd", pwd);			
			User user = (User) q.uniqueResult();
			close();
			return user;
		} catch (HibernateException e) {
			rollback();
			throw new Exception("Could not get user " + username, e);
		}
	}
	
	public User get(String username){
		try {
			begin();
			Query q = getSession().createQuery("from User where username = :username");
			q.setString("username",username);
			User user = (User) q.uniqueResult();
			close();
			return user;
			
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
			return null;
		
	}
	

	public User register(User u) throws Exception {
		try {
			begin();
			System.out.println("inside DAO");
			getSession().save(u);
			commit();
			close();
			return u;

		} catch (HibernateException e) {
			rollback();
			throw new Exception("Exception while creating user: " + e.getMessage());
		}
	}
	
	public Booking getBooking(int id) {
		try {
			begin();
			
			Query q = getSession().getNamedQuery("findBookingByID")
		    .setInteger("booking_id", id);
		        	
			Booking results = (Booking) q.uniqueResult();
			close();
			return results;
			
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
			return null;
		
	}

}
