package com.me.project.dao;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Restrictions;

import com.me.project.pojo.Booking;
import com.me.project.pojo.Flight;
import com.me.project.pojo.Seat;
import com.me.project.pojo.User;

public class SeatDAO extends DAO{
	
public SeatDAO() {
		
	}

public Seat get(String seat_id, Flight flight, String type) throws Exception {
	try {
		begin();
		int id=flight.getFlight_id();
//		
//		Query q = getSession().createQuery("from Seat as s where s.seat_id = :seat_id and s.seatType=:seatType");
//		q.setString("seat_id", seat_id);
//		q.setString("seatType", type);

		//Seat s = (Seat) q.list();
		//q.setMaxResults(1);
		
		Criteria c = getSession().createCriteria(Seat.class);
		c.add(Restrictions.eq("seatType", type));
		c.add(Restrictions.eq("seat_id", seat_id));
		Criteria fl  = c.createCriteria("flight");
		fl.add(Restrictions.eq("flight_id", flight.getFlight_id()));
		
		c.setMaxResults(1);
		Seat s =(Seat) c.uniqueResult();
		
		System.out.println("hello: "+ s.getId());
		close();
		return s;
	} catch (HibernateException e) {
		rollback();
		throw new Exception("Could not get seat " + seat_id, e);
	}

}

public Seat getSeatById(int id) throws Exception {
	try {
		begin();

		
		
		Query q = getSession().getNamedQuery("findSeatBypID")
			    .setInteger("id", id);
			        	
		Seat results = (Seat) q.uniqueResult();
		
		System.out.println("hello: "+ results.getId());
		close();
		return results;
	} catch (HibernateException e) {
		rollback();
		throw new Exception("Could not get seat " + id, e);
	}

}

public void save(Seat s) throws Exception {
	try {
		begin();
		System.out.println("inside DAO");
		getSession().saveOrUpdate(s);
		commit();
		close();
	} catch (HibernateException e) {
		rollback();
		throw new Exception("Exception while updateing seat: " + e.getMessage());
	}
}

}
