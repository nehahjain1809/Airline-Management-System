package com.me.project.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.beans.factory.annotation.Autowired;

@Entity
@Table(name="flight")
@NamedQueries ({

		@NamedQuery(name = "findAllFlights", query = "FROM Flight where departure_city = :departure_city and "
				+ "arrival_city= :arrival_city and departure_date>= :departure_date"),
		@NamedQuery(name = "findFlightById", query = "FROM Flight where flight_id = :flight_id"),
		@NamedQuery(name = "findAllFlights1", query = "FROM Flight"),
		@NamedQuery(name = "findAllFlightsFrom", query = "FROM Flight where departure_city = :departure_city and "
				+ "departure_date >= :departure_date ")
		})
public class Flight {

	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int flight_id;
	
	@ManyToOne()
    @JoinColumn(name="airline_id")
	private Airline airline;
	
	@Column(name="flight_no")
	private String flight_no;
	

	@Column(name="departure_city")
	private String departure_city;
	

	@Column(name="arrival_city")
	private String arrival_city;
	
//	@OneToOne
//    @JoinColumn(name="city_id" , insertable = false, updatable = false)
//	private City departure_city;
//	
//	@OneToOne
//	@JoinColumn(name="city_id", insertable = false, updatable = false)
//	//@Transient
//	private City arrival_city;
//	
//	
	@Column(name="departure_date")
	private Date departure_date;
	
		
	@Column(name="arrival_date")
	private Date arrival_Date;
	
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "flight", cascade= CascadeType.ALL)
	private List<Seat> seats;
	
		
	@Column(name="totalEconomySeats")
	private int totalEconomySeats;
	
	@Column(name="totalFirstSeats")
	private int totalFirstSeats;
	
	@Column(name="totalBusinessSeats")
	private int totalBusinessSeats;
	
//	public void initializeSeats(int e, int b, int f) {
//		seats = new ArrayList();
//		for(int i = 1; i<= (e+b+f); i++) {
//			Seat s =  new Seat();
//			s.setSeat_id(i);
//			s.setBooked(false);
//			s.setCheckedIn(false);
//			seats.add(s);
//		}
//	}
	
	public int getFlight_id() {
		return flight_id;
	}


	public void setFlight_id(int flight_id) {
		this.flight_id = flight_id;
	}


	public Airline getAirline() {
		return airline;
	}


	public void setAirline(Airline airline) {
		this.airline = airline;
	}


	public String getFlight_no() {
		return flight_no;
	}


	public void setFlight_no(String flight_no) {
		this.flight_no = flight_no;
	}


	

	public Date getDeparture_date() {
		return departure_date;
	}


	public void setDeparture_date(Date departure_date) {
		this.departure_date = departure_date;
	}


	public String getDeparture_city() {
		return departure_city;
	}

	public void setDeparture_city(String departure_city) {
		this.departure_city = departure_city;
	}

	public String getArrival_city() {
		return arrival_city;
	}

	public void setArrival_city(String arrival_city) {
		this.arrival_city = arrival_city;
	}

	public Date getArrival_Date() {
		return arrival_Date;
	}


	public void setArrival_Date(Date arrival_Date) {
		this.arrival_Date = arrival_Date;
	}


	public List<Seat> getSeats() {
		return seats;
	}


	public void setSeats(List<Seat> seats) {
		this.seats = seats;
	}


	
	public int getTotalEconomySeats() {
		return totalEconomySeats;
	}


	public void setTotalEconomySeats(int totalEconomySeats) {
		this.totalEconomySeats = totalEconomySeats;
	}


	public int getTotalFirstSeats() {
		return totalFirstSeats;
	}


	public void setTotalFirstSeats(int totalFirstSeats) {
		this.totalFirstSeats = totalFirstSeats;
	}


	public int getTotalBusinessSeats() {
		return totalBusinessSeats;
	}


	public void setTotalBusinessSeats(int totalBusinessSeats) {
		this.totalBusinessSeats = totalBusinessSeats;
	}	
	
	
}
