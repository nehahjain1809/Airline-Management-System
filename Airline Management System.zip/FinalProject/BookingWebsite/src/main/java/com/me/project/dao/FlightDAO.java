package com.me.project.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.me.project.pojo.Booking;
import com.me.project.pojo.Flight;
import com.me.project.pojo.Seat;
import com.me.project.pojo.User;

public class FlightDAO extends DAO {

	public FlightDAO() {
		
	}
	
	public List<Flight> search(String departure, String arrival, Date departure_date) throws Exception {
		try {
			List<Flight> flightList = new ArrayList<Flight>();
			begin();
			Session session = DAO.getSession();
			
			System.out.println("in dao var");
        	System.out.println("departure city:" + departure);
        	System.out.println("arrival city:" + arrival);
        	System.out.println("date: "+departure_date);
        	
        	Query q = session.getNamedQuery("findAllFlights")
        	.setString("departure_city", departure)
        	.setString("arrival_city", arrival)
        	.setDate("departure_date", departure_date);
        	flightList = q.list();
        	
        	for(Flight f: flightList)
        	System.out.println("flight from data: " + f.getDeparture_city());
        	close();
			return flightList;
		} catch (HibernateException e) {
			rollback();
			throw new Exception("Could not get flights " ,e);
		}
	}
	
	public List<Flight> searchAllFlightsFrom(String departure, Date departure_date) throws Exception {
		try {
			List<Flight> flightList = new ArrayList<Flight>();
			begin();
			Session session = DAO.getSession();
			Date departure_date21 = departure_date;
			Calendar c = Calendar.getInstance();
	        c.setTime(departure_date21);
	        c.add(Calendar.DATE, 1);
	        Date departure_date2 = c.getTime();
	        
        	Query q = session.getNamedQuery("findAllFlightsFrom")
        	.setString("departure_city", departure)
        	.setDate("departure_date", departure_date);
//        	.setDate("departure_date2", departure_date2);
        	
        	flightList = q.list();
        	close();
			return flightList;
		} catch (HibernateException e) {
			rollback();
			throw new Exception("Could not get flights " ,e);
		}
	}
	
	public void addFlights(List<Flight> flights) {
		try {
		Transaction tx = getSession().getTransaction();
		tx.begin();
		for(Flight f: flights) {
			getSession().save(f);
		}
		tx.commit();
	
		}
		catch(HibernateException e) {
			e.printStackTrace();
		}
	}
	
	public List<Flight> viewAll() {
		
		List<Flight> allFlightList = getSession().getNamedQuery("findAllFlights1").list();
		System.out.println("in viewall:" + allFlightList.size() );
		return allFlightList;
	}
	
	public void delete(int flight_id) {
		try {
		Transaction tx = getSession().getTransaction();
		tx.begin();
		Flight f =  (Flight) getSession().getNamedQuery("findFlightById").setInteger("flight_id", flight_id).uniqueResult();
		getSession().delete(f);
		tx.commit();
		}
		catch(HibernateException e) {
			e.printStackTrace();
		}
	}
	
	public Flight get(int flight_id) throws Exception {
		try {
			begin();
			Query q = getSession().createQuery("from Flight where flight_id = :flight_id");
			q.setInteger("flight_id", flight_id);			
			Flight f = (Flight) q.uniqueResult();
			close();
			return f;
		} catch (HibernateException e) {
			rollback();
			throw new Exception("Could not get flight " + flight_id, e);
		}
	
	}
	
//	public Flight get1(String flight_no) throws Exception {
//		try {
//			
//			Query q = getSession().createQuery("from Flight where flight_no = :flight_no");
//			q.setString("flight_no", flight_no);			
//			Flight f = (Flight) q.uniqueResult();
//			return f;
//		} catch (HibernateException e) {
//			rollback();
//			throw new Exception("Could not get flight " + flight_no, e);
//		}
//	
//	}
	
	public float getPriceBySeatType(String seattype, int flight_id) {
		
		begin();
//		Query q = getSession().createQuery("select distinct(s.seatPrice) from Flight as f inner join f.seats as s"
//				+ " where s.seatType = :seattype and f.flight_id= :flight_id");
//		q.setString("seattype", seattype);
//		q.setInteger("flight_id", flight_id);
		
//		q.setMaxResults(1);
		SQLQuery query = getSession().createSQLQuery("select distinct(seatPrice) from seat  as s inner join "
				+ "flight as f on s.flightid = f.flight_id where f.flight_id ="+flight_id+ " and s.seattype ='"+ seattype+"'");
		
		float price = (Float) query.uniqueResult();
		System.out.println("price2: " + price);
		close();
		return price;
		
	}
	
	public void addSeats(String flight_no, int e, int b, int f) throws Exception {
		//Flight fl = get1(flight_no);
		Query q = getSession().createQuery("from Flight where flight_no = :flight_no");
		q.setString("flight_no", flight_no);	
		q.setMaxResults(1);
		Flight fl = (Flight) q.uniqueResult();
		List<Seat> seats = new ArrayList<Seat>();
		int numRows = 10;
		int numCols = 6;

		  int i = 0;
		  int j = 0;
		  char columns;
		  for (i = 1; i <= 4; ++i) {
		     columns = 'A';
		     for (j = 1; j <= numCols; ++j) {
		    	String seat_id = ""+i + columns + "";
		    	Seat s = new Seat();
				s.setSeat_id(seat_id);
				s.setSeatType("economy");
				s.setSeatPrice(500);
				s.setAllowed_baggage(2);
				s.setBooked(false);
				s.setCheckedIn(false);
				s.setFlight(fl);
				seats.add(s);
		        columns++;
		     }
		  }
		  
		  for (i = 5; i <= 7; ++i) {
			     columns = 'A';
			     for (j = 1; j <= numCols; ++j) {
			    	String seat_id = ""+i + columns + "";
			    	Seat s = new Seat();
					s.setSeat_id(seat_id);
					s.setSeatType("business");
					s.setSeatPrice(1000);
					s.setAllowed_baggage(2);
					s.setBooked(false);
					s.setCheckedIn(false);
					s.setFlight(fl);
					seats.add(s);
			        columns++;
			     }
			  }
			  
		  
		  for (i = 8; i <= 10; ++i) {
			     columns = 'A';
			     for (j = 1; j <= numCols; ++j) {
			    	String seat_id = ""+i + columns + "";
			    	Seat s = new Seat();
					s.setSeat_id(seat_id);
					s.setSeatType("firstclass");
					s.setSeatPrice(1500);
					s.setAllowed_baggage(2);
					s.setBooked(false);
					s.setCheckedIn(false);
					s.setFlight(fl);
					seats.add(s);
			        columns++;
			     }
			  }
			  
		  
//		for(int i = 1 ; i<= 20; i++) {
//			Seat s = new Seat();
//			s.setSeat_id(String.valueOf(i));
//			s.setSeatType("economy");
//			s.setSeatPrice(500);
//			s.setAllowed_baggage(2);
//			s.setBooked(false);
//			s.setCheckedIn(false);
//			s.setFlight(fl);
//			seats.add(s);
//			
//		}
//		
//		for(int i = 51 ; i<= 100; i++) {
//			Seat s = new Seat();
//			s.setSeat_id(String.valueOf(i));
//			s.setSeatType("business");
//			s.setSeatPrice(1000);
//			s.setAllowed_baggage(2);
//			s.setBooked(false);
//			s.setCheckedIn(false);
//			s.setFlight(fl);
//			seats.add(s);
//			
//		}
//		
//		for(int i = 101 ; i<= 150; i++) {
//			Seat s = new Seat();
//			s.setSeat_id(String.valueOf(i));
//			s.setSeatType("firstclass");
//			s.setSeatPrice(1500);
//			s.setAllowed_baggage(2);
//			s.setBooked(false);
//			s.setCheckedIn(false);
//			s.setFlight(fl);
//			seats.add(s);
//		}
		Transaction tx = getSession().getTransaction();
		tx.begin();
		for(Seat s: seats) {
			getSession().save(s);
		}
		tx.commit();
		System.out.println(seats.size());
		fl.setSeats(seats);
	}
	
	public int saveBooking(Booking b, Seat s) {
		Transaction tx = getSession().getTransaction();
		tx.begin();
		
			getSession().save(b);
			getSession().saveOrUpdate(s);
		tx.commit();
		
		return b.getBooking_id();
	}
}
