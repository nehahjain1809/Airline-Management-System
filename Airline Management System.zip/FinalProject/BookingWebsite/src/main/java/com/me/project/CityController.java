package com.me.project;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.me.project.dao.CityDAO;
import com.me.project.pojo.City;


@Controller
@RequestMapping(value="/user/city/*")
public class CityController {
	
	@Autowired
	@Qualifier("cityDao")
	CityDAO cityDao;

	@RequestMapping(value="/user/city/add", method = RequestMethod.POST)
	public String createCity(HttpServletRequest request,  ModelMap map) {
		
		HttpSession session = request.getSession();
		
		String city_name = request.getParameter("city");
		City city = new City();
		city.setCity_name(city_name);
		
		try{
		cityDao.add(city);
		session.setAttribute("message", "City added successfully");
		return "admin-dashboard";
	
		}
		catch(Exception e) {
			return "error-page";
		}
	}
}
