package com.me.project.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="airline")
@NamedQueries ({
	@NamedQuery(name = "findAirlineById", query = "FROM Airline a WHERE  a.airline_id =:airline_id")
	})
public class Airline {

	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int airline_id;
	
	@Column(name="airline_name")
	private String airline_name;

	public int getAirline_id() {
		return airline_id;
	}

	public void setAirline_id(int airline_id) {
		this.airline_id = airline_id;
	}

	public String getAirline_name() {
		return airline_name;
	}

	public void setAirline_name(String airline_name) {
		this.airline_name = airline_name;
	}
	
	
}
