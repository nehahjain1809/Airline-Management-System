package com.me.airliner.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.me.airliner.dao.DAO;
import com.me.airliner.dao.FlightDAO;
import com.me.airliner.dao.UserDAO;
import com.me.airliner.helper.UploadHelper;
import com.me.airliner.pojo.Airline;
import com.me.airliner.pojo.Flight;

@Controller
@RequestMapping(value="/flight/*")
public class AddFlightController {

	@RequestMapping(value="/" , method = RequestMethod.GET)
	public String initForm(ModelMap model){
		
		return "edit-flight";
		
	}
	@RequestMapping(value="/flight/view" , method = RequestMethod.POST)
	public String viewFlightData(HttpServletRequest request, HttpServletResponse response, FlightDAO flightDao, ModelMap model){
		HttpSession session = request.getSession();
		List<Flight> allFlights = flightDao.viewAll();
		session.setAttribute("allFlights", allFlights);
    	System.out.println(allFlights);
    	return "edit-flight";
		
	}
	
	@RequestMapping(value="/flight/upload" , method = RequestMethod.POST)
	public String uploadFlightData(HttpServletRequest request, HttpServletResponse response , ModelMap model) throws ClassNotFoundException, SQLException{
		HttpSession session = request.getSession();
		String filename	= request.getParameter("filename");
		System.out.println(filename);
        if(!filename.equals("")){
        	UploadHelper uploadHelper = new UploadHelper();
        	List<Flight> flights = uploadHelper.parseData(filename);
        	session.setAttribute("flights", flights);
        	System.out.println(flights);
        	return "edit-flight";
        }
        else {
        	session.setAttribute("message", "Invalid Filename");
        	return  "Invalid Filename";
        }
		
		
	}
	
	@RequestMapping(value="/flight/add" , method = RequestMethod.POST)
	public String addFlightData(HttpServletRequest request, HttpServletResponse response, FlightDAO flightDao, ModelMap model){
		HttpSession session = request.getSession();
		List<Flight> flights_to_add = (List<Flight>) session.getAttribute("flights");
		
		flightDao.addFlights(flights_to_add);
		return "edit-flight-success";
		
	}
	
	@RequestMapping(value="/flight/delete" , method = RequestMethod.POST)
	public String deleteFlightData(HttpServletRequest request, HttpServletResponse response , FlightDAO flightDao, ModelMap model){
		System.out.print("delete");
		String[] flighsToDelete =  request.getParameterValues("deleteSelect");
		for (String str : flighsToDelete) {
			int flight_id = Integer.parseInt(str);
			System.out.print(flight_id);
			
			Session session = DAO.getSession();
        	Query query = session.getNamedQuery("findFlightById").setInteger("flight_id",flight_id);
        	query.setMaxResults(1);
        	Flight flight = (Flight) query.uniqueResult();
        	flightDao.delete(flight);
		}
		 
		return "edit-flight-success";
		
	}
	
	@RequestMapping(value="/flight/search" , method = RequestMethod.POST)
	public String searchFlightData(HttpServletRequest request, 
		HttpServletResponse response ,
		FlightDAO flightDao, ModelMap model){
		
		System.out.println("hi");
		List<Flight> allFlights = flightDao.viewAll();
		for(Flight f: allFlights) {
			System.out.println(f.getFlight_from());
			System.out.println(f.getFlight_to());
		}
		String source = request.getParameter("from") ;
		String destination = request.getParameter("to") ;
		
		
		
		List<Flight> filteredFlights = flightDao.getFlights(allFlights, source, destination);
		HttpSession session = request.getSession();
		System.out.println(filteredFlights.size());
		session.setAttribute("filteredFlights", filteredFlights);
    	return "flight-searchresults";
		
	}
}
