package com.me.airliner.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.captcha.botdetect.web.servlet.Captcha;
import com.me.airliner.dao.DAO;
import com.me.airliner.dao.FlightDAO;
import com.me.airliner.dao.UserDAO;
import com.me.airliner.pojo.Flight;
import com.me.airliner.pojo.User;

@Controller
@RequestMapping(value="/")
public class UserController extends DAO {


	List<String> allCityList ;
	
	
@RequestMapping(value="/" , method = RequestMethod.GET)
public String initForm(ModelMap model){
	
	//cityList = new ArrayList<String>();
	allCityList = getSession().getNamedQuery("findAllCities").list();
	//System.out.print(allCityList.size());
	//return form view
	return "index";
	
}


@RequestMapping(value = "/user/", method = RequestMethod.GET)
public String showCreateForm(ModelMap model) {
	User user = new User();
	model.addAttribute("user", user);

	return "signup-form";
}

@RequestMapping(value = "/login/", method = RequestMethod.GET)
public String showLoginForm(HttpServletRequest request) {
	//<%
	
    Cookie[] ck = request.getCookies();
    ///String act =request.getParameter("action");
	if (ck != null) {
		for (int i = 0; i < ck.length; i++) {
			String name = ck[i].getName();
			String value = ck[i].getValue();
			if (name.equals("username")) {
				request.getSession().setAttribute("username", ck[i].getValue());
				return "user-dashboard";
                                  
			}

	} 
	}
	else {
		return "login-form";
	}
  
	return "login-form";
 

}

@RequestMapping(value = "/dashboard/", method = RequestMethod.GET)
public String showDashboard(ModelMap model) {
	User user = new User();
	model.addAttribute("user", user);

	return "user-dashboard";
}


@RequestMapping(value = "/login/validate", method = RequestMethod.POST) 
public String handleLoginForm(HttpServletRequest request, HttpServletResponse response, 
		UserDAO userDao, ModelMap map) {

	String username = request.getParameter("username");
	String password = request.getParameter("password");
	System.out.println(username);
	HttpSession session = request.getSession();
	session.setAttribute("username", username);
	System.out.println("h1");
	boolean remember;
	 if(request.getParameter("rememberMe")==null){
         remember=false;  
         System.out.println("h2");
       }
       else{
           remember=true;
           System.out.println("h3");
       }
	try {
		User u = userDao.get(username, password);

		if (u != null) {
			if(remember) { 
				System.out.println("h4");
			Cookie ck=new Cookie("username",username); 
            ck.setMaxAge(60*60);
            response.addCookie(ck);  
			}
			System.out.println("h5");
            return "user-dashboard";
			
		} 
		else {
			System.out.println("h6");
			map.addAttribute("errorMessage", "Invalid username/password!");
			return "error-page";
		}
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	return null;

}


@RequestMapping(value="/user/register", method = RequestMethod.POST)
public String handleCreateForm(HttpServletRequest request, UserDAO userDao, ModelMap map) {
    
    // captcha object
    Captcha captcha = Captcha.load(request, "CaptchaObject");
    
    // captcha code the user typed id
    String captchaCode = request.getParameter("captchaCode");
    
    //creating a session
    HttpSession session=request.getSession();
    
    System.out.println("H1");
    if(captcha.validate(captchaCode)){
        //if captcha code is correct


        
        User user = new User();
        user.setFirstName(request.getParameter("firstname"));
        user.setLastName(request.getParameter("lastName"));
        user.setBirthday(request.getParameter("birthday"));
        user.setContact(request.getParameter("contact"));
        user.setPassport(request.getParameter("passport"));
        user.setEmail(request.getParameter("email"));
        String userEmail= request.getParameter("username");
        String password = request.getParameter("password");
        user.setUsername(userEmail);
        user.setPassword(password);
        
        try{
        User u = userDao.register(user);

        
        return "user-created-success";
        
        }catch(Exception e){
            e.printStackTrace();
        }
//        
    }else
    {
        
        
        map.addAttribute("errorMessage","Invalid Captcha Code");
        return "error-page";
    }
	return "error-page";
 
}

@RequestMapping(value = "/ajaxservice", method = RequestMethod.POST)
@ResponseBody
public String ajaxService(HttpServletRequest request)
{
	
	String queryString = request.getParameter("city");
	System.out.println("Querystring:"+ queryString);
	String result = "";
	if( queryString.length() > 0) {
		System.out.println("in Querystring:");
	for(int i = 0; i< allCityList.size(); i++){
		if(allCityList.get(i).toLowerCase().contains(queryString.toLowerCase())){
			result += allCityList.get(i)+",";
		}
	}
	
	}
	else { return null; }
	
//	System.out.println(result);
	return result;
}

/*@RequestMapping(value="/flight/search" , method = RequestMethod.POST)
public String searchFlightData(HttpServletRequest request, 
	HttpServletResponse response ,
	FlightDAO flightDao, ModelMap model){
	
	System.out.println("hi");
	List<Flight> allFlights = flightDao.viewAll();
	String source = request.getParameter("from") ;
	String destination = request.getParameter("to") ;
	
	System.out.println(allFlights);
	
	List<Flight> filteredFlights = flightDao.getFlights(allFlights, source, destination);
	return "flight-searchresults";
	
}*/


}
