package com.me.airliner.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="airplane")
@NamedQueries ({
	@NamedQuery(name = "findAirplaneById", query = "FROM Airplane a WHERE  a.airplane_id =:airplane_id")
	})
public class Airplane {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="airplane_id")
	private int airplane_id;
	
	@Column(name="airplane_name")
	private String airplane_name;
	
	@OneToOne
	@JoinColumn(name = "airline_id")
	Airline airline;

	public int getAirplane_id() {
		return airplane_id;
	}

	public void setAirplane_id(int airplane_id) {
		this.airplane_id = airplane_id;
	}

	public String getAirplane_name() {
		return airplane_name;
	}

	public void setAirplane_name(String airplane_name) {
		this.airplane_name = airplane_name;
	}

	public Airline getAirline() {
		return airline;
	}

	public void setAirline(Airline airline) {
		this.airline = airline;
	}
	
	
}
	
