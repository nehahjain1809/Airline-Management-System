package com.me.airliner.pojo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name="flight")
@NamedQueries ({
	@NamedQuery(name = "findAllFlights", query = "FROM Flight"),
	@NamedQuery(name = "findFlightById", query = "FROM Flight where flight_id = :flight_id")
	})
public class Flight {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="flight_id")
	private int flight_id;
	
	
    @JoinColumn(name = "airline_id")
	private int airline_id;
	
	
    @JoinColumn(name = "airplane_id")
	private int airplane_id;
	
	
    @JoinColumn(name = "city_id")
	private int flight_from;
	
	
    @JoinColumn(name = "city_id")
	private int flight_to;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="flight_depart_time")
	private Date flight_depart_time;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "flight_arrival_time")
	private Date flight_arrival_time;

	public int getFlight_id() {
		return flight_id;
	}

	public void setFlight_id(int flight_id) {
		this.flight_id = flight_id;
	}

	
	
	public int getAirline_id() {
		return airline_id;
	}

	public void setAirline_id(int airline_id) {
		this.airline_id = airline_id;
	}

	public int getAirplane_id() {
		return airplane_id;
	}

	public void setAirplane_id(int airplane_id) {
		this.airplane_id = airplane_id;
	}

	public int getFlight_from() {
		return flight_from;
	}

	public void setFlight_from(int flight_from) {
		this.flight_from = flight_from;
	}

	public int getFlight_to() {
		return flight_to;
	}

	public void setFlight_to(int flight_to) {
		this.flight_to = flight_to;
	}

	public Date getFlight_depart_time() {
		return flight_depart_time;
	}

	public void setFlight_depart_time(Date flight_depart_time) {
		this.flight_depart_time = flight_depart_time;
	}

	public Date getFlight_arrival_time() {
		return flight_arrival_time;
	}

	public void setFlight_arrival_time(Date flight_arrival_time) {
		this.flight_arrival_time = flight_arrival_time;
	}

	
	
	
}
