package com.me.airliner.pojo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="airline")
@NamedQueries ({
	@NamedQuery(name = "findAirlineById", query = "FROM Airline a WHERE  a.airline_id =:airline_id")
	})
public class Airline {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="airline_id")
	private int airline_id;
	
	@Column(name="airline_name")
	private String airliner_name;
	
	

	public int getAirline_id() {
		return airline_id;
	}

	public void setAirline_id(int airline_id) {
		this.airline_id = airline_id;
	}

	public String getAirliner_name() {
		return airliner_name;
	}

	public void setAirliner_name(String airliner_name) {
		this.airliner_name = airliner_name;
	}
	
	
	
}
