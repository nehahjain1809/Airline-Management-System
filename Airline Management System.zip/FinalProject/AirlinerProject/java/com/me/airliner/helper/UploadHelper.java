package com.me.airliner.helper;

import java.util.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.helpers.DateTimeDateFormat;
import org.hibernate.HibernateException;
import org.hibernate.query.Query;
import org.hibernate.Session;
import org.relique.jdbc.csv.CsvConnection;
import org.relique.jdbc.csv.CsvPreparedStatement;
import org.relique.jdbc.csv.CsvResultSet;

import com.me.airliner.dao.DAO;
import com.me.airliner.pojo.Airline;
import com.me.airliner.pojo.Airplane;
import com.me.airliner.pojo.Flight;

public class UploadHelper extends DAO{

	public List<Flight> parseData(String filename) throws ClassNotFoundException, SQLException {
		
		System.out.println("in method");
		try{
		Class.forName("org.relique.jdbc.csv.CsvDriver");
        CsvConnection conn=(CsvConnection) DriverManager.getConnection("jdbc:relique:csv:");
        CsvPreparedStatement stmt = (CsvPreparedStatement) conn.prepareStatement("select * FROM "+filename+ ";");
        CsvResultSet results =(CsvResultSet) stmt.executeQuery("select * FROM "+filename + ";");
        
        List<Flight> flights = new ArrayList<Flight>();
        
        System.out.println("connection: " +conn);
        System.out.println("statement: " +stmt);
        
        while(results.next()){
        	Flight flight = new Flight();
        	System.out.println("resultset loop");
        	
        	
        		
        	try {
        	Session session = DAO.getSession();
        	Query query = session.getNamedQuery("findAirlineById").setInteger("airline_id", results.getInt("Airline_id"));
        	//query.setParameter("airline_id", results.getInt("Airline_Id"));
        	query.setMaxResults(1);
        	Airline airline = (Airline) query.uniqueResult();
        	
        	
        	Query query2 = session.getNamedQuery("findAirplaneById").setInteger("airplane_id", results.getInt("Airplane_id"));
        	query2.setMaxResults(1);
        	Airplane airplane = (Airplane) query2.uniqueResult();
        	
        	flight.setAirline_id(airline.getAirline_id());
        	flight.setAirplane_id(airplane.getAirplane_id());
        	}
        	catch(HibernateException e) {
        		e.printStackTrace();
        	}
        	
        	
        	String csv_departure= results.getString("Departure");
        	System.out.println(csv_departure);
//        	String csv_departure = csv_departure1.substring(0,csv_departure1.length()-2);
        	Date departure=(Date) new SimpleDateFormat("MM/dd/yyyy HH:mm").parse(csv_departure);
        	
           	String csv_arrival= results.getString("Arrival");
           	System.out.println(csv_arrival);
//           	String csv_arrival = csv_arrival1.substring(0,csv_arrival1.length()-2);
        	Date arrival=(Date) new SimpleDateFormat("MM/dd/yyyy HH:mm").parse(csv_arrival);
        	
        	flight.setFlight_from(results.getInt("Source"));
        	flight.setFlight_to(results.getInt("Destination"));
        	flight.setFlight_depart_time(departure);
        	flight.setFlight_arrival_time(arrival);
        	
        	flights.add(flight);
        	
        }
        System.out.println("flights: " + flights);
        return flights;
		}
    	catch(Exception e) {
    		e.printStackTrace();
    		return null;
    	}
		
	}
}
