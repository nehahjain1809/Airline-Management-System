package com.me.airliner.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.me.airliner.pojo.Flight;

public class FlightDAO extends DAO{

	public void addFlights(List<Flight> flights) {
		try {
		Transaction tx = getSession().getTransaction();
		tx.begin();
		for(Flight f: flights) {
			getSession().save(f);
		}
		tx.commit();
		}
		catch(HibernateException e) {
			e.printStackTrace();
		}
	}
	
	public List<Flight> viewAll() {
		
		List<Flight> allFlightList = getSession().getNamedQuery("findAllFlights").list();
		System.out.println("in dao:" + allFlightList.size() );
		return allFlightList;
	}
	
	public void delete(Flight flight) {
		try {
			Transaction tx = getSession().getTransaction();
			tx.begin();
			getSession().delete(flight);
			tx.commit();
		}
			catch(HibernateException e) {
				e.printStackTrace();
			}
	}
	
	public List<Flight> getFlights(List<Flight> allFlights, String source, String destination) {
		List<Flight> filteredFlights = new ArrayList<Flight>();
		
		for(Flight flight: allFlights) {
			Session session = DAO.getSession();
        	Query query = session.getNamedQuery("findCityById").setInteger("city_id",flight.getFlight_from());
        	query.setMaxResults(1);
        	Query query1 = session.getNamedQuery("findCityById").setInteger("city_id",flight.getFlight_to());
        	query1.setMaxResults(1);
        	String from = (String) query.uniqueResult();
        	String to = (String) query1.uniqueResult();
        	
			if(from.equals(source) && to.equals(destination)) {
				filteredFlights.add(flight);
			}
		}
		System.out.println(filteredFlights.size());
		return filteredFlights;
	}
}
